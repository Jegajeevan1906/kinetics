# Kinetic — Premium Laptop E-Commerce Prototype

A full-featured, high-fidelity e-commerce prototype for a premium laptop retailer, built as a real React app you can run, deploy, and extend.

## Stack

- React 19 + TypeScript + Vite
- React Router v7 (client-side routing across ~35 pages)
- Tailwind CSS v4 (custom design tokens — see `src/index.css`)
- Recharts (admin analytics charts)
- lucide-react (icons)
- All data is mock/in-memory, persisted to `localStorage` under the key `kinetic_store_v1` — no backend required.

## Getting started

```bash
npm install
npm run dev       # start local dev server (http://localhost:5173)
npm run build     # production build -> dist/
npm run preview   # preview the production build locally
```

## What's included

**Storefront:** Home, product listing (all/category/deals/new-arrivals/brands), search with history, product details (gallery, specs, reviews, similar/related), cart, checkout (address, delivery, payment method - with a demo "simulate failure" toggle), payment success/failed, order tracking with a live status timeline, wishlist, notifications.

**Auth:** Login, Register, Forgot Password, OTP verification (any 4 digits work in the demo).

**Customer account:** Dashboard, orders, order tracking, saved addresses, profile, settings.

**Admin console** (`/admin`): dashboard, analytics (charts), product management (add/edit/delete), categories, inventory (stock adjustment), orders (status updates that sync live to the customer's tracking page), customers, coupons, reviews, notification broadcast, store settings.

## Notes for going to production

- Swap the `StoreProvider` in `src/lib/store.tsx` for real API calls / a backend (e.g. Supabase, or your own REST/GraphQL API) - the store's public interface (`useStore()`) is designed so pages don't need to change much.
- Product images are placeholder photos from picsum.photos - replace with real product photography.
- Payment is fully simulated; integrate a real gateway (e.g. Razorpay) in `src/pages/Checkout.tsx`.
- Auth is simulated (no password checking); wire up real authentication before launch.
