import { useMemo, useState, useEffect } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { SlidersHorizontal, PackageSearch, X } from 'lucide-react';
import { useStore } from '../lib/store';
import { ProductCard } from '../components/ProductCard';
import { FilterSidebar, defaultFilters, type Filters } from '../components/FilterSidebar';
import { Breadcrumb, EmptyState, PageTitle, SkeletonGrid } from '../components/Common';
import { categories } from '../data/products';
import { discountPercent } from '../lib/format';

type Mode = 'all' | 'category' | 'search' | 'deals' | 'new-arrivals' | 'brands';

export function ProductListing({ mode }: { mode: Mode }) {
  const { products, addSearchHistory, searchHistory } = useStore();
  const params = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const [filters, setFilters] = useState<Filters>(defaultFilters);
  const [sort, setSort] = useState(searchParams.get('sort') || 'popular');
  const [mobileFilters, setMobileFilters] = useState(false);
  const [loading, setLoading] = useState(true);

  const brandParam = searchParams.get('brand');
  const query = searchParams.get('q') || '';
  const categoryId = params.categoryId;

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 350);
    return () => clearTimeout(t);
  }, [mode, categoryId, query]);

  useEffect(() => {
    if (mode === 'search' && query) addSearchHistory(query);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query, mode]);

  const filtered = useMemo(() => {
    let list = [...products];
    if (mode === 'category' && categoryId) list = list.filter((p) => p.category === categoryId);
    if (mode === 'deals') list = list.filter((p) => discountPercent(p.price, p.mrp) >= 8);
    if (mode === 'new-arrivals') list = list.filter((p) => p.badges?.includes('New') || true).slice().reverse();
    if (mode === 'search' && query) {
      const q = query.toLowerCase();
      list = list.filter((p) => [p.name, p.brand, p.processor, p.category].some((f) => f.toLowerCase().includes(q)));
    }
    if (brandParam) list = list.filter((p) => p.brand === brandParam);

    if (filters.brands.length) list = list.filter((p) => filters.brands.includes(p.brand));
    if (filters.processor.length) list = list.filter((p) => filters.processor.some((f) => p.processor.includes(f)));
    if (filters.ram.length) list = list.filter((p) => filters.ram.some((f) => p.ram.includes(f)));
    if (filters.storage.length) list = list.filter((p) => filters.storage.some((f) => p.storage.includes(f)));
    if (filters.graphics.length) list = list.filter((p) => filters.graphics.some((f) => p.graphics.includes(f)));
    list = list.filter((p) => p.price <= filters.maxPrice);
    if (filters.minRating) list = list.filter((p) => p.rating >= filters.minRating);
    if (filters.inStockOnly) list = list.filter((p) => p.stock > 0);

    switch (sort) {
      case 'price-asc': list.sort((a, b) => a.price - b.price); break;
      case 'price-desc': list.sort((a, b) => b.price - a.price); break;
      case 'latest': list.reverse(); break;
      case 'rating': list.sort((a, b) => b.rating - a.rating); break;
      case 'discount': list.sort((a, b) => discountPercent(b.price, b.mrp) - discountPercent(a.price, a.mrp)); break;
      default: list.sort((a, b) => b.reviewCount - a.reviewCount);
    }
    return list;
  }, [products, mode, categoryId, query, brandParam, filters, sort]);

  const title =
    mode === 'category' ? categories.find((c) => c.id === categoryId)?.label ?? 'Category'
    : mode === 'search' ? `Results for "${query}"`
    : mode === 'deals' ? "Today's Deals"
    : mode === 'new-arrivals' ? 'New Arrivals'
    : mode === 'brands' ? `${brandParam ?? 'All'} Laptops`
    : 'All Laptops';

  return (
    <div className="mx-auto max-w-7xl px-5 py-8 sm:px-6 lg:px-8">
      <Breadcrumb items={[{ label: title }]} />
      <div className="mt-3 flex items-center justify-between gap-4">
        <PageTitle title={title} subtitle={`${filtered.length} laptop${filtered.length === 1 ? '' : 's'} found`} />
        <button onClick={() => setMobileFilters(true)} className="flex shrink-0 items-center gap-1.5 rounded-full border border-hairline bg-card px-3.5 py-2.5 text-xs font-semibold text-ink shadow-sm sm:hidden">
          <SlidersHorizontal size={14} /> Filters
        </button>
      </div>

      {mode === 'search' && searchHistory.length > 0 && (
        <div className="mb-6 flex flex-wrap items-center gap-2 text-xs">
          <span className="text-ink-muted">Recent searches:</span>
          {searchHistory.map((h) => (
            <button key={h} onClick={() => setSearchParams({ q: h })} className="rounded-full border border-hairline bg-card px-2.5 py-1 text-ink transition-colors hover:border-primary hover:text-primary">{h}</button>
          ))}
        </div>
      )}

      <div className="flex gap-8">
        <div className="hidden sm:block">
          <FilterSidebar filters={filters} setFilters={setFilters} />
        </div>

        {mobileFilters && (
          <div className="fixed inset-0 z-50 flex sm:hidden">
            <div className="absolute inset-0 bg-ink/50 backdrop-blur-sm" onClick={() => setMobileFilters(false)} />
            <div className="relative ml-auto h-full w-[85%] max-w-xs overflow-y-auto bg-canvas p-5 shadow-2xl animate-fade-in">
              <button onClick={() => setMobileFilters(false)} className="mb-4 flex items-center gap-1 text-sm font-semibold text-ink-muted"><X size={16} /> Close</button>
              <FilterSidebar filters={filters} setFilters={setFilters} />
            </div>
          </div>
        )}

        <div className="min-w-0 flex-1">
          <div className="mb-4 flex justify-end">
            <select value={sort} onChange={(e) => setSort(e.target.value)} className="rounded-full border border-hairline bg-card px-4 py-2.5 text-xs font-medium text-ink shadow-sm outline-none focus:border-primary">
              <option value="popular">Sort: Popular</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="latest">Latest</option>
              <option value="rating">Highest Rated</option>
              <option value="discount">Discount</option>
            </select>
          </div>

          {loading ? (
            <SkeletonGrid />
          ) : filtered.length === 0 ? (
            mode === 'search' ? (
              <EmptyState icon={PackageSearch} title="No results found" body={`We couldn't find any laptops matching "${query}". Try a different keyword or clear your filters.`} />
            ) : (
              <EmptyState icon={PackageSearch} title="No laptops match your filters" body="Try adjusting or clearing your filters to see more results." />
            )
          ) : (
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {filtered.map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
