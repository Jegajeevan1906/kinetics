import { StaticPage } from '../components/StaticPage';

export function About() {
  return (
    <StaticPage title="About Kinetic" subtitle="India's premium destination for high-performance laptops.">
      <p>Kinetic was founded in 2024 with a simple premise: buying a serious laptop in India shouldn't mean wading through a hundred near-identical listings with no real guidance. We curate a focused catalog of ultrabooks, gaming rigs, workstations and business machines, and stand behind every unit with Kinetic Care warranty support.</p>
      <h3>What we do differently</h3>
      <p>Every product on Kinetic is inspected before dispatch, listed with real specifications (not marketing copy), and backed by GST-compliant invoicing. Our support team is trained on the hardware we sell, not just order status.</p>
      <h3>Where we operate</h3>
      <p>We currently ship across India from fulfilment centers in Bengaluru, Pune and Delhi NCR, with express delivery available in most metro pincodes.</p>
      <h3>Careers</h3>
      <p>We're a small, product-obsessed team. If you care about hardware and customer experience in equal measure, reach out via our contact page.</p>
    </StaticPage>
  );
}
