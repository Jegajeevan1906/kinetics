import { StaticPage } from '../components/StaticPage';

export function Terms() {
  return (
    <StaticPage title="Terms & Conditions" subtitle="Last updated July 2026">
      <p>By accessing or using kinetic.in, you agree to the following terms.</p>
      <h3>Orders & pricing</h3>
      <p>All prices are listed in Indian Rupees and inclusive of applicable GST unless stated otherwise. We reserve the right to correct pricing errors and to cancel orders placed at an incorrect price, with a full refund.</p>
      <h3>Product availability</h3>
      <p>Stock levels shown on product pages are indicative and updated regularly, but availability is confirmed only at the time of order confirmation.</p>
      <h3>Warranty</h3>
      <p>Each product page lists the applicable Kinetic Care warranty term. Warranty covers manufacturing defects and does not cover accidental or liquid damage unless a protection plan was purchased separately.</p>
      <h3>Account responsibility</h3>
      <p>You are responsible for maintaining the confidentiality of your account credentials and for all activity under your account.</p>
      <h3>Limitation of liability</h3>
      <p>Kinetic's liability for any claim relating to a purchase is limited to the value of that order.</p>
    </StaticPage>
  );
}
