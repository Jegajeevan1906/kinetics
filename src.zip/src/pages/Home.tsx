import { Link } from 'react-router-dom';
import { ArrowRight, Cpu, ShieldCheck, Truck, Star, Quote } from 'lucide-react';
import { useStore } from '../lib/store';
import { categories, brands } from '../data/products';
import { ProductCard } from '../components/ProductCard';
import { SectionHeading } from '../components/Common';
import { discountPercent, formatINR } from '../lib/format';

const testimonials = [
  { name: 'Ishaan Kapoor', role: 'Freelance Video Editor', quote: 'Ordered the Vantage Pro 16 for color grading work. Delivery was two days early and the calibration out of the box was spot on.' },
  { name: 'Meera Suresh', role: 'B.Tech Student, VIT', quote: 'The Campus Book 15 handles everything from AutoCAD assignments to late-night streaming without breaking a sweat.' },
  { name: 'Farhan Ali', role: 'Startup Founder', quote: 'Kinetic Care support replaced a faulty battery within 48 hours, no questions asked. That kind of service is rare.' },
];

export function Home() {
  const { products } = useStore();
  const featured = products.slice(0, 4);
  const trending = [...products].sort((a, b) => b.reviewCount - a.reviewCount).slice(0, 4);
  const newArrivals = products.filter((p) => p.badges?.includes('New')).concat(products.slice(-2)).slice(0, 4);
  const bestSellers = products.filter((p) => p.badges?.includes('Bestseller')).slice(0, 4);
  const deals = products.filter((p) => discountPercent(p.price, p.mrp) > 0).sort((a, b) => discountPercent(b.price, b.mrp) - discountPercent(a.price, a.mrp)).slice(0, 4);

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-hairline bg-canvas-secondary">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_80%_0%,rgba(37,99,235,0.12),transparent_55%)]" />
        <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-10 px-6 py-16 md:grid-cols-2 md:py-24 lg:px-8">
          <div className="animate-fade-in">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-hairline bg-card px-3.5 py-1.5 text-xs font-semibold text-primary shadow-sm">
              <Cpu size={13} /> NEW ARRIVALS · JULY 2026
            </div>
            <h1 className="font-display text-4xl font-black leading-[1.08] tracking-tight text-ink sm:text-5xl">
              Engineered for whatever you build next.
            </h1>
            <p className="mt-5 max-w-md text-ink-muted">
              Premium ultrabooks, gaming rigs and ISV-certified workstations — curated for India, backed by Kinetic Care warranty and GST invoicing on every order.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/products" className="flex items-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-semibold text-white shadow-pill transition-all hover:-translate-y-0.5 hover:bg-primary-hover">
                Shop All Laptops <ArrowRight size={16} />
              </Link>
              <Link to="/deals" className="flex items-center gap-2 rounded-full border border-hairline bg-card px-6 py-3.5 text-sm font-semibold text-ink transition-colors hover:border-primary hover:text-primary">
                Today's Deals
              </Link>
            </div>
            <div className="mt-11 grid max-w-md grid-cols-3 gap-4 text-xs text-ink-muted">
              <div><div className="font-display text-xl font-extrabold text-ink">120+</div>Models curated</div>
              <div><div className="font-display text-xl font-extrabold text-ink">48hr</div>Avg. dispatch</div>
              <div><div className="font-display text-xl font-extrabold text-ink">4.6★</div>Avg. rating</div>
            </div>
          </div>
          <div className="relative">
            <div className="overflow-hidden rounded-[24px] border border-hairline shadow-card-hover">
              <img src="https://picsum.photos/seed/kinetic-hero/900/700" alt="Featured laptop" className="w-full object-cover" />
            </div>
            <div className="absolute -bottom-5 -left-5 hidden rounded-2xl border border-hairline bg-card px-5 py-3.5 shadow-card-hover sm:block">
              <div className="text-[11px] font-semibold uppercase tracking-wide text-ink-muted">STRIKE X15 · RTX 4070</div>
              <div className="font-display text-lg font-extrabold text-primary">{formatINR(124990)}</div>
            </div>
          </div>
        </div>
      </section>

      {/* Category strip */}
      <section className="mx-auto max-w-7xl px-6 py-12 lg:px-8">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-6">
          {categories.map((c) => (
            <Link key={c.id} to={`/category/${c.id}`} className="group flex flex-col items-center gap-2 rounded-2xl border border-hairline bg-card px-3 py-6 text-center shadow-card transition-all hover:-translate-y-1 hover:border-primary/30 hover:shadow-card-hover">
              <span className="font-display text-sm font-bold text-ink group-hover:text-primary">{c.label}</span>
              <span className="text-[11px] text-ink-muted">{c.description}</span>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-12 lg:px-8">
        <SectionHeading eyebrow="Curated" title="Featured Laptops" action={<Link to="/products" className="text-sm font-semibold text-primary hover:underline">View all</Link>} />
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {featured.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-12 lg:px-8">
        <SectionHeading eyebrow="Most Reviewed" title="Trending Now" action={<Link to="/products?sort=popular" className="text-sm font-semibold text-primary hover:underline">View all</Link>} />
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {trending.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-12 lg:px-8">
        <SectionHeading eyebrow="Just In" title="New Arrivals" action={<Link to="/new-arrivals" className="text-sm font-semibold text-primary hover:underline">View all</Link>} />
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {newArrivals.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-12 lg:px-8">
        <SectionHeading eyebrow="Fan Favorites" title="Best Sellers" />
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {bestSellers.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>

      <section className="border-y border-hairline bg-canvas-secondary">
        <div className="mx-auto max-w-7xl px-6 py-12 lg:px-8">
          <SectionHeading eyebrow="Limited Time" title="Today's Deals" action={<Link to="/deals" className="text-sm font-semibold text-primary hover:underline">View all</Link>} />
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {deals.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-12 lg:px-8">
        <SectionHeading eyebrow="Trusted Names" title="Popular Brands" />
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-5">
          {brands.map((b) => (
            <Link key={b} to={`/products?brand=${b}`} className="flex items-center justify-center rounded-2xl border border-hairline bg-card py-6 font-display text-sm font-bold text-ink-muted shadow-card transition-all hover:-translate-y-1 hover:border-primary/30 hover:text-primary">
              {b}
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-12 lg:px-8">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <TrustCard icon={ShieldCheck} title="Kinetic Care Warranty" body="Up to 3-year onsite coverage on every order." />
          <TrustCard icon={Truck} title="Fast, Tracked Delivery" body="Dispatch within 48 hours, live order tracking." />
          <TrustCard icon={Star} title="4.6★ Average Rating" body="Backed by 15,000+ verified customer reviews." />
        </div>
      </section>

      <section className="border-t border-hairline bg-canvas-secondary">
        <div className="mx-auto max-w-7xl px-6 py-16 lg:px-8">
          <SectionHeading eyebrow="Customer Stories" title="What buyers are saying" />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            {testimonials.map((t) => (
              <div key={t.name} className="rounded-2xl border border-hairline bg-card p-6 shadow-card">
                <Quote size={18} className="text-primary" />
                <p className="mt-3 text-sm leading-relaxed text-ink-muted">{t.quote}</p>
                <div className="mt-4 text-sm font-semibold text-ink">{t.name}</div>
                <div className="text-xs text-ink-muted">{t.role}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

function TrustCard({ icon: Icon, title, body }: { icon: typeof ShieldCheck; title: string; body: string }) {
  return (
    <div className="flex items-start gap-3.5 rounded-2xl border border-hairline bg-card p-6 shadow-card">
      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary/10">
        <Icon size={20} className="text-primary" />
      </div>
      <div>
        <div className="font-display text-sm font-bold text-ink">{title}</div>
        <div className="mt-1 text-xs text-ink-muted">{body}</div>
      </div>
    </div>
  );
}
