import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { Breadcrumb, PageTitle } from '../components/Common';

const faqs = [
  { q: 'How long does delivery take?', a: 'Standard delivery takes 3–6 business days depending on your pincode. Express delivery (1–2 days) is available at checkout for most metro cities.' },
  { q: 'Do you offer no-cost EMI?', a: 'Yes, no-cost EMI is available on orders above ₹15,000 across major banks and cards, selectable at checkout.' },
  { q: 'What is Kinetic Care warranty?', a: 'Kinetic Care is our extended warranty program covering hardware defects, accidental damage (select plans), and onsite service in 30+ cities.' },
  { q: 'Can I return a laptop if I change my mind?', a: 'Yes, unopened products can be returned within 7 days of delivery. See our Return Policy page for full details and exclusions.' },
  { q: 'Do you provide GST invoices?', a: 'Every order includes a GST-compliant tax invoice, available for download from My Orders once your order ships.' },
  { q: 'Is Cash on Delivery available?', a: 'COD is available on orders below ₹75,000 in serviceable pincodes. Check availability by entering your pincode on any product page.' },
];

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <Breadcrumb items={[{ label: 'FAQ' }]} />
      <PageTitle title="Frequently Asked Questions" />
      <div className="divide-y divide-line rounded-xl border border-line bg-graphite-800">
        {faqs.map((f, i) => (
          <div key={f.q}>
            <button onClick={() => setOpen(open === i ? null : i)} className="flex w-full items-center justify-between px-5 py-4 text-left text-sm font-medium">
              {f.q}
              <ChevronDown size={16} className={`shrink-0 text-muted transition-transform ${open === i ? 'rotate-180 text-copper-400' : ''}`} />
            </button>
            {open === i && <div className="px-5 pb-4 text-sm text-muted">{f.a}</div>}
          </div>
        ))}
      </div>
    </div>
  );
}
