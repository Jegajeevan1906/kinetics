import { StaticPage } from '../components/StaticPage';

export function ReturnPolicy() {
  return (
    <StaticPage title="Return Policy" subtitle="7-day replacement window on all laptops">
      <p>We want you to be confident in every purchase. If something isn't right, here's how returns work.</p>
      <h3>Eligibility</h3>
      <p>Laptops are eligible for replacement within 7 days of delivery if they arrive damaged, defective, or materially different from what was ordered. The unit must be in its original packaging with all accessories.</p>
      <h3>How to request a return</h3>
      <p>Go to My Orders, select the relevant order, and choose "Request Replacement." Our team will arrange a reverse pickup within 2 business days.</p>
      <h3>Refunds</h3>
      <p>For orders paid online, refunds are processed to the original payment method within 5–7 business days of the returned unit passing quality inspection. Cash on Delivery orders are refunded via bank transfer.</p>
      <h3>Non-returnable situations</h3>
      <p>Physical damage caused after delivery, missing accessories, or units without original packaging are not eligible for replacement, but may still qualify for chargeable repair under warranty.</p>
    </StaticPage>
  );
}
