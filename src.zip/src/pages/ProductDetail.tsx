import { useParams, Link } from 'react-router-dom';
import { useState } from 'react';
import { Heart, Truck, ShieldCheck, RefreshCw, ZoomIn, CircleCheck, CircleX } from 'lucide-react';
import { useStore } from '../lib/store';
import { formatINR, discountPercent, deliveryDateFrom, formatDate } from '../lib/format';
import { Breadcrumb, EmptyState } from '../components/Common';
import { StarRating, RatingBadge } from '../components/StarRating';
import { ProductCard } from '../components/ProductCard';
import { categories } from '../data/products';
import { PackageX } from 'lucide-react';

export function ProductDetail() {
  const { slug } = useParams();
  const { products, wishlist, toggleWishlist, addToCart, pushToast } = useStore();
  const product = products.find((p) => p.slug === slug);
  const [activeImg, setActiveImg] = useState(0);
  const [zoom, setZoom] = useState(false);
  const [pincode, setPincode] = useState('');
  const [pincodeResult, setPincodeResult] = useState<string | null>(null);
  const [tab, setTab] = useState<'specs' | 'description' | 'reviews'>('specs');

  if (!product) {
    return (
      <div className="mx-auto max-w-3xl px-6 py-16">
        <EmptyState icon={PackageX} title="Product not found" body="This laptop may have been removed or is no longer available." action={<Link to="/products" className="rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-white shadow-pill">Browse Laptops</Link>} />
      </div>
    );
  }

  const off = discountPercent(product.price, product.mrp);
  const inWishlist = wishlist.includes(product.id);
  const similar = products.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4);
  const related = products.filter((p) => p.brand === product.brand && p.id !== product.id).slice(0, 4);

  const checkPincode = () => {
    if (!/^\d{6}$/.test(pincode)) {
      setPincodeResult('Enter a valid 6-digit pincode');
      return;
    }
    setPincodeResult(`Delivery available — arrives by ${deliveryDateFrom(product.deliveryDays)}`);
  };

  return (
    <div className="mx-auto max-w-7xl px-5 py-8 sm:px-6 lg:px-8">
      <Breadcrumb items={[
        { label: categories.find((c) => c.id === product.category)?.label ?? '', href: `/category/${product.category}` },
        { label: product.name },
      ]} />

      <div className="mt-5 grid grid-cols-1 gap-10 lg:grid-cols-2">
        {/* Gallery */}
        <div>
          <div className="relative overflow-hidden rounded-[24px] border border-hairline bg-canvas-secondary shadow-card">
            <img
              src={product.images[activeImg]}
              alt={product.name}
              onMouseEnter={() => setZoom(true)}
              onMouseLeave={() => setZoom(false)}
              className={`aspect-[4/3] w-full object-cover transition-transform duration-500 ${zoom ? 'scale-125' : 'scale-100'}`}
            />
            <div className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full bg-white/90 text-ink-muted shadow-sm">
              <ZoomIn size={15} />
            </div>
            {product.badges?.[0] && (
              <span className="absolute left-3 top-3 rounded-full bg-accent px-3 py-1 text-[11px] font-bold text-white shadow-sm">{product.badges[0]}</span>
            )}
          </div>
          <div className="mt-3 flex gap-2">
            {product.images.map((img, i) => (
              <button key={img} onClick={() => setActiveImg(i)} className={`h-16 w-16 overflow-hidden rounded-xl border-2 transition-colors ${activeImg === i ? 'border-primary' : 'border-hairline'}`}>
                <img src={img} alt="" className="h-full w-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Info */}
        <div>
          <span className="text-xs font-semibold uppercase tracking-wide text-ink-muted">{product.brand}</span>
          <h1 className="mt-1 font-display text-2xl font-extrabold tracking-tight text-ink sm:text-3xl">{product.name}</h1>
          <div className="mt-2 flex items-center gap-3">
            <RatingBadge rating={product.rating} reviewCount={product.reviewCount} />
            <span className={`text-xs font-semibold ${product.stock > 0 ? 'text-success' : 'text-discount'}`}>
              {product.stock > 0 ? `In Stock (${product.stock} left)` : 'Out of Stock'}
            </span>
          </div>

          <div className="mt-4 flex items-baseline gap-3">
            <span className="font-display text-3xl font-extrabold text-ink">{formatINR(product.price)}</span>
            {off > 0 && (
              <>
                <span className="text-ink-muted line-through">{formatINR(product.mrp)}</span>
                <span className="rounded-md bg-success/15 px-2 py-0.5 text-xs font-bold text-success">{off}% off</span>
              </>
            )}
          </div>
          <div className="mt-1 text-xs text-ink-muted">Inclusive of all taxes · No-cost EMI available</div>

          <ul className="mt-5 grid grid-cols-1 gap-1.5 text-xs text-ink-muted sm:grid-cols-2">
            <li>CPU: {product.processor}</li>
            <li>RAM: {product.ram}</li>
            <li>Storage: {product.storage}</li>
            <li>GPU: {product.graphics}</li>
            <li>Display: {product.display}</li>
            <li>Battery: {product.battery}</li>
          </ul>

          <div className="mt-5 flex flex-wrap gap-2">
            {product.highlights.map((h) => (
              <span key={h} className="rounded-full border border-hairline bg-canvas-secondary px-3 py-1 text-xs font-medium text-ink-muted">{h}</span>
            ))}
          </div>

          {/* Pincode checker */}
          <div className="mt-6 rounded-2xl border border-hairline bg-card p-4 shadow-card">
            <div className="flex items-center gap-2 text-sm font-semibold text-ink"><Truck size={16} className="text-primary" /> Check delivery</div>
            <div className="mt-2 flex gap-2">
              <input value={pincode} onChange={(e) => setPincode(e.target.value)} maxLength={6} placeholder="Enter pincode" className="w-32 rounded-full border border-hairline bg-search px-4 py-2 text-sm outline-none focus:border-primary" />
              <button onClick={checkPincode} className="rounded-full bg-ink px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-primary">Check</button>
            </div>
            {pincodeResult && <div className="mt-2 text-xs font-medium text-primary">{pincodeResult}</div>}
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3 text-xs text-ink-muted">
            <div className="flex items-center gap-2"><ShieldCheck size={16} className="text-primary" /> {product.warranty}</div>
            <div className="flex items-center gap-2"><RefreshCw size={16} className="text-primary" /> 7-day replacement</div>
          </div>

          <div className="mt-6 flex gap-3">
            <button
              onClick={() => addToCart(product.id)}
              disabled={product.stock === 0}
              className="flex-1 rounded-full border border-hairline bg-card py-3.5 text-sm font-semibold text-ink shadow-sm transition-colors hover:border-primary hover:text-primary disabled:opacity-40"
            >
              Add to Cart
            </button>
            <Link
              to="/checkout"
              onClick={(e) => { if (product.stock === 0) { e.preventDefault(); return; } addToCart(product.id); }}
              className={`flex-1 rounded-full py-3.5 text-center text-sm font-semibold text-white shadow-pill transition-colors ${product.stock === 0 ? 'pointer-events-none bg-canvas-secondary text-ink-muted' : 'bg-primary hover:bg-primary-hover'}`}
            >
              Buy Now
            </Link>
            <button
              onClick={() => toggleWishlist(product.id)}
              aria-label="Toggle wishlist"
              className={`flex h-[52px] w-[52px] shrink-0 items-center justify-center rounded-full border transition-colors ${inWishlist ? 'border-primary bg-primary/10 text-primary' : 'border-hairline text-ink-muted hover:border-primary hover:text-primary'}`}
            >
              <Heart size={18} className={inWishlist ? 'fill-current' : ''} />
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="mt-14 border-b border-hairline">
        <div className="flex gap-6 text-sm">
          {(['specs', 'description', 'reviews'] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)} className={`border-b-2 py-3 font-semibold capitalize transition-colors ${tab === t ? 'border-primary text-ink' : 'border-transparent text-ink-muted hover:text-ink'}`}>
              {t === 'specs' ? 'Specifications' : t}
              {t === 'reviews' && ` (${product.reviews.length})`}
            </button>
          ))}
        </div>
      </div>

      <div className="py-8">
        {tab === 'specs' && (
          <div className="grid max-w-3xl grid-cols-1 gap-x-8 gap-y-3 sm:grid-cols-2">
            {[
              ['Processor', product.processor], ['RAM', product.ram], ['Storage', product.storage], ['Graphics', product.graphics],
              ['Display', product.display], ['Battery', product.battery], ['Weight', product.weight], ['Operating System', product.os],
              ['Ports', product.ports.join(', ')], ['Warranty', product.warranty],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between border-b border-hairline py-2.5 text-sm">
                <span className="text-ink-muted">{k}</span>
                <span className="text-right font-semibold text-ink">{v}</span>
              </div>
            ))}
          </div>
        )}
        {tab === 'description' && (
          <div className="max-w-2xl space-y-4 text-sm leading-relaxed text-ink-muted">
            <p>{product.description}</p>
            <div className="flex items-center gap-2 text-success"><CircleCheck size={16} /> {product.stock > 0 ? `${product.stock} units in stock` : 'Currently unavailable'}</div>
            {product.stock === 0 && <div className="flex items-center gap-2 text-discount"><CircleX size={16} /> Notify me when back in stock</div>}
          </div>
        )}
        {tab === 'reviews' && (
          <div className="max-w-2xl space-y-5">
            <div className="flex items-center gap-4 rounded-2xl border border-hairline bg-card p-5 shadow-card">
              <div className="font-display text-4xl font-extrabold text-ink">{product.rating.toFixed(1)}</div>
              <div>
                <StarRating rating={product.rating} size={16} />
                <div className="mt-1 text-xs text-ink-muted">{product.reviewCount} verified ratings</div>
              </div>
            </div>
            {product.reviews.map((r) => (
              <div key={r.id} className="border-b border-hairline pb-5">
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-ink">{r.author}</div>
                  <span className="text-xs text-ink-muted">{formatDate(r.date)}</span>
                </div>
                <StarRating rating={r.rating} size={13} />
                <div className="mt-1 text-sm font-semibold text-ink">{r.title}</div>
                <p className="mt-1 text-sm text-ink-muted">{r.body}</p>
                {r.verified && <span className="mt-1 inline-block text-[11px] font-semibold text-success">Verified Purchase</span>}
              </div>
            ))}
            <button onClick={() => pushToast('Review submission is disabled in this demo', 'info')} className="rounded-full border border-hairline bg-card px-4 py-2.5 text-xs font-semibold text-ink transition-colors hover:border-primary hover:text-primary">
              Write a Review
            </button>
          </div>
        )}
      </div>

      {similar.length > 0 && (
        <section className="py-8">
          <h3 className="mb-4 font-display text-xl font-extrabold text-ink">Similar Products</h3>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {similar.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}
      {related.length > 0 && (
        <section className="py-8">
          <h3 className="mb-4 font-display text-xl font-extrabold text-ink">More from {product.brand}</h3>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {related.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}
    </div>
  );
}
