import { useState } from 'react';
import { useStore } from '../../lib/store';
import { formatINR, formatDate } from '../../lib/format';
import type { OrderStage } from '../../data/types';

const stages: OrderStage[] = ['Placed', 'Confirmed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered'];

export function AdminOrders() {
  const { orders, updateOrderStage } = useStore();
  const [expanded, setExpanded] = useState<string | null>(null);

  return (
    <div>
      <h1 className="font-display text-2xl font-bold">Orders</h1>
      <p className="mt-1 text-sm text-muted">{orders.length} total orders. Update status to sync with the customer's tracking page.</p>

      {orders.length === 0 ? (
        <p className="mt-6 text-sm text-muted">No orders placed yet. Orders placed on the storefront will appear here in real time.</p>
      ) : (
        <div className="mt-6 space-y-3">
          {orders.map((o) => (
            <div key={o.id} className="rounded-xl border border-line bg-graphite-800 p-4">
              <button onClick={() => setExpanded(expanded === o.id ? null : o.id)} className="flex w-full flex-wrap items-center justify-between gap-2 text-left">
                <div>
                  <div className="font-mono-data text-xs text-muted">{o.id}</div>
                  <div className="text-sm">{o.customerName} · {formatDate(o.date)}</div>
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-semibold">{formatINR(o.total)}</span>
                  <span className="rounded-full bg-copper-500/15 px-2.5 py-1 text-xs text-copper-400">{o.stage}</span>
                </div>
              </button>

              {expanded === o.id && (
                <div className="mt-4 border-t border-line pt-4">
                  <div className="mb-3 space-y-2">
                    {o.items.map((it) => (
                      <div key={it.productId} className="flex items-center gap-3 text-sm">
                        <img src={it.image} alt="" className="h-10 w-10 rounded-lg object-cover" />
                        <span className="flex-1">{it.name} × {it.qty}</span>
                        <span>{formatINR(it.price * it.qty)}</span>
                      </div>
                    ))}
                  </div>
                  <div className="mb-3 text-xs text-muted">Deliver to: {o.address.name}, {o.address.line1}, {o.address.city} {o.address.pincode}</div>
                  <label className="mb-1 block text-xs text-muted">Update order status</label>
                  <select
                    value={o.stage}
                    onChange={(e) => updateOrderStage(o.id, e.target.value as OrderStage)}
                    className="input"
                  >
                    {stages.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
