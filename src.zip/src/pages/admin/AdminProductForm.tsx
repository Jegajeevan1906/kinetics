import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useStore } from '../../lib/store';
import { categories } from '../../data/products';
import type { Product } from '../../data/types';

const blank: Omit<Product, 'id' | 'slug' | 'reviews'> = {
  brand: '', name: '', category: 'ultrabook', price: 0, mrp: 0, rating: 4.5, reviewCount: 0, stock: 10,
  images: ['https://picsum.photos/seed/newproduct/800/600'], processor: '', ram: '', storage: '', graphics: '',
  display: '', battery: '', weight: '', os: 'Windows 11 Home', ports: [], highlights: [], description: '',
  warranty: '1 Year Standard', deliveryDays: 4, badges: [],
};

export function AdminProductForm({ mode }: { mode: 'add' | 'edit' }) {
  const { products, addProduct, updateProduct } = useStore();
  const navigate = useNavigate();
  const { id } = useParams();
  const existing = mode === 'edit' ? products.find((p) => p.id === id) : undefined;

  const [form, setForm] = useState(existing ?? { id: '', slug: '', reviews: [], ...blank });

  const set = <K extends keyof typeof form>(key: K, value: (typeof form)[K]) => setForm((f) => ({ ...f, [key]: value }));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const slug = form.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    if (mode === 'add') {
      addProduct({ ...form, id: `p${Date.now()}`, slug, reviews: [] } as Product);
    } else {
      updateProduct(form as Product);
    }
    navigate('/admin/products');
  };

  return (
    <div>
      <h1 className="font-display text-2xl font-bold">{mode === 'add' ? 'Add Product' : 'Edit Product'}</h1>
      <p className="mt-1 text-sm text-muted">{mode === 'add' ? 'Create a new laptop listing.' : `Editing ${existing?.name}`}</p>

      <form onSubmit={submit} className="mt-6 grid max-w-3xl grid-cols-1 gap-4 rounded-xl border border-line bg-graphite-800 p-6 sm:grid-cols-2">
        <LabeledInput label="Brand" value={form.brand} onChange={(v) => set('brand', v)} required />
        <LabeledInput label="Model Name" value={form.name} onChange={(v) => set('name', v)} required />

        <div>
          <label className="mb-1 block text-xs text-muted">Category</label>
          <select value={form.category} onChange={(e) => set('category', e.target.value as Product['category'])} className="input w-full">
            {categories.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
          </select>
        </div>
        <LabeledInput label="Warranty" value={form.warranty} onChange={(v) => set('warranty', v)} />

        <LabeledInput label="Price (₹)" type="number" value={String(form.price)} onChange={(v) => set('price', Number(v))} required />
        <LabeledInput label="MRP (₹)" type="number" value={String(form.mrp)} onChange={(v) => set('mrp', Number(v))} required />
        <LabeledInput label="Stock" type="number" value={String(form.stock)} onChange={(v) => set('stock', Number(v))} />
        <LabeledInput label="Delivery Days" type="number" value={String(form.deliveryDays)} onChange={(v) => set('deliveryDays', Number(v))} />

        <LabeledInput label="Processor" value={form.processor} onChange={(v) => set('processor', v)} />
        <LabeledInput label="RAM" value={form.ram} onChange={(v) => set('ram', v)} />
        <LabeledInput label="Storage" value={form.storage} onChange={(v) => set('storage', v)} />
        <LabeledInput label="Graphics" value={form.graphics} onChange={(v) => set('graphics', v)} />
        <LabeledInput label="Display" value={form.display} onChange={(v) => set('display', v)} />
        <LabeledInput label="Battery" value={form.battery} onChange={(v) => set('battery', v)} />

        <div className="sm:col-span-2">
          <label className="mb-1 block text-xs text-muted">Product Image URL</label>
          <input value={form.images[0]} onChange={(e) => set('images', [e.target.value, ...form.images.slice(1)])} className="input w-full" />
        </div>

        <div className="sm:col-span-2">
          <label className="mb-1 block text-xs text-muted">Description</label>
          <textarea rows={3} value={form.description} onChange={(e) => set('description', e.target.value)} className="input w-full resize-none" />
        </div>

        <div className="flex gap-2 sm:col-span-2">
          <button type="submit" className="rounded-lg bg-copper-500 px-5 py-2.5 text-xs font-semibold text-graphite-950">
            {mode === 'add' ? 'Add Product' : 'Save Changes'}
          </button>
          <button type="button" onClick={() => navigate('/admin/products')} className="rounded-lg border border-line px-5 py-2.5 text-xs">Cancel</button>
        </div>
      </form>
    </div>
  );
}

function LabeledInput({ label, value, onChange, type = 'text', required }: { label: string; value: string; onChange: (v: string) => void; type?: string; required?: boolean }) {
  return (
    <div>
      <label className="mb-1 block text-xs text-muted">{label}</label>
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)} required={required} className="input w-full" />
    </div>
  );
}
