import { Link } from 'react-router-dom';
import { Heart, Trash2, ShoppingCart } from 'lucide-react';
import { useStore } from '../../lib/store';
import { PageTitle, EmptyState } from '../../components/Common';
import { formatINR } from '../../lib/format';
import { RatingBadge } from '../../components/StarRating';

export function Wishlist() {
  const { wishlist, products, toggleWishlist, moveWishlistToCart } = useStore();
  const items = wishlist.map((id) => products.find((p) => p.id === id)).filter(Boolean) as typeof products;

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-6 py-16">
        <EmptyState icon={Heart} title="Your wishlist is empty" body="Save laptops you love here to compare and buy later."
          action={<Link to="/products" className="rounded-full bg-copper-500 px-5 py-2 text-sm font-semibold text-graphite-950">Browse Laptops</Link>} />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-6 py-8">
      <PageTitle title="Wishlist" subtitle={`${items.length} saved item${items.length === 1 ? '' : 's'}`} />
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((p) => (
          <div key={p.id} className="rounded-xl border border-line bg-graphite-800 p-4">
            <Link to={`/product/${p.slug}`}><img src={p.images[0]} alt={p.name} className="aspect-[4/3] w-full rounded-lg object-cover" /></Link>
            <div className="mt-3 text-xs uppercase tracking-wide text-muted">{p.brand}</div>
            <Link to={`/product/${p.slug}`} className="font-display text-sm font-semibold hover:text-copper-400">{p.name}</Link>
            <div className="mt-1"><RatingBadge rating={p.rating} reviewCount={p.reviewCount} /></div>
            <div className="mt-2 font-display text-base font-bold">{formatINR(p.price)}</div>
            <div className="mt-3 flex gap-2">
              <button onClick={() => moveWishlistToCart(p.id)} className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-copper-500 py-2 text-xs font-semibold text-graphite-950 hover:bg-copper-400">
                <ShoppingCart size={13} /> Move to Cart
              </button>
              <button onClick={() => toggleWishlist(p.id)} className="flex h-8 w-8 items-center justify-center rounded-lg border border-line text-muted hover:border-danger hover:text-danger">
                <Trash2 size={14} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
