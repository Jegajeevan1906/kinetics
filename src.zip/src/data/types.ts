export interface Review {
  id: string;
  author: string;
  rating: number;
  title: string;
  body: string;
  date: string;
  verified: boolean;
}

export interface Product {
  id: string;
  slug: string;
  brand: string;
  name: string;
  category: 'ultrabook' | 'gaming' | 'workstation' | 'business' | 'student' | '2in1';
  price: number;
  mrp: number;
  rating: number;
  reviewCount: number;
  stock: number;
  images: string[];
  processor: string;
  ram: string;
  storage: string;
  graphics: string;
  display: string;
  battery: string;
  weight: string;
  os: string;
  ports: string[];
  highlights: string[];
  description: string;
  warranty: string;
  deliveryDays: number;
  badges?: string[];
  reviews: Review[];
}

export interface Address {
  id: string;
  label: string;
  name: string;
  line1: string;
  city: string;
  state: string;
  pincode: string;
  phone: string;
  isDefault?: boolean;
}

export interface CartItem {
  productId: string;
  qty: number;
  savedForLater?: boolean;
}

export interface OrderItem {
  productId: string;
  name: string;
  image: string;
  price: number;
  qty: number;
}

export type OrderStage = 'Placed' | 'Confirmed' | 'Packed' | 'Shipped' | 'Out for Delivery' | 'Delivered';

export interface Order {
  id: string;
  date: string;
  items: OrderItem[];
  total: number;
  address: Address;
  paymentMethod: string;
  stage: OrderStage;
  customerName: string;
  customerEmail: string;
}

export interface Coupon {
  code: string;
  description: string;
  discountPercent: number;
  minOrder: number;
  active: boolean;
}

export interface Notification {
  id: string;
  title: string;
  body: string;
  date: string;
  read: boolean;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  joined: string;
  orders: number;
  totalSpent: number;
  status: 'Active' | 'Blocked';
}

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  phone: string;
}
