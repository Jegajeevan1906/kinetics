import type { Product, Review } from './types';

const img = (seed: string, n: number) =>
  Array.from({ length: n }, (_, i) => `https://picsum.photos/seed/${seed}-${i}/800/600`);

const sampleReviews = (seed: string): Review[] => [
  {
    id: `${seed}-r1`,
    author: 'Aarav Mehta',
    rating: 5,
    title: 'Excellent build and performance',
    body: 'Been using this for three weeks now for design work. Thermals stay controlled even under load and the display is crisp. Battery easily lasts a full day of mixed use.',
    date: '2026-06-02',
    verified: true,
  },
  {
    id: `${seed}-r2`,
    author: 'Priya Nair',
    rating: 4,
    title: 'Great value, average speakers',
    body: 'Solid machine for the price. Keyboard feels premium and the trackpad is accurate. Only complaint is the speakers sound a bit thin at high volume.',
    date: '2026-05-20',
    verified: true,
  },
  {
    id: `${seed}-r3`,
    author: 'Rohan Desai',
    rating: 5,
    title: 'Delivered a day early',
    body: 'Kinetic packaging was excellent, no dents on the box. Setup was quick and the pre-installed apps were minimal, which I appreciated.',
    date: '2026-04-11',
    verified: false,
  },
];

export const products: Product[] = [
  {
    id: 'p1', slug: 'aeris-slim-14', brand: 'Aeris', name: 'Aeris Slim 14',
    category: 'ultrabook', price: 74990, mrp: 89990, rating: 4.5, reviewCount: 312, stock: 18,
    images: img('aeris14', 4), processor: 'Intel Core Ultra 7 155H', ram: '16GB LPDDR5', storage: '512GB NVMe SSD',
    graphics: 'Intel Arc Integrated', display: '14" 2.8K OLED, 120Hz', battery: '68Wh, up to 16 hrs', weight: '1.2 kg',
    os: 'Windows 11 Home', ports: ['2x Thunderbolt 4', '1x USB-A 3.2', 'HDMI 2.1', '3.5mm audio'],
    highlights: ['Ultra-slim 14.9mm chassis', 'OLED HDR display', 'MIL-STD-810H tested', '65W USB-C fast charging'],
    description: 'The Aeris Slim 14 is built for professionals who move fast. A featherweight magnesium-alloy body houses a vivid OLED panel and enough power for demanding creative workflows on the go.',
    warranty: '2 Year Kinetic Care', deliveryDays: 3, badges: ['Bestseller'], reviews: sampleReviews('aeris14'),
  },
  {
    id: 'p2', slug: 'vantage-pro-16', brand: 'Vantage', name: 'Vantage Pro 16',
    category: 'workstation', price: 189990, mrp: 214990, rating: 4.7, reviewCount: 154, stock: 7,
    images: img('vantage16', 4), processor: 'Intel Core i9-14900HX', ram: '64GB DDR5', storage: '2TB NVMe SSD',
    graphics: 'NVIDIA RTX 4000 Ada 12GB', display: '16" 4K mini-LED, 100% DCI-P3', battery: '99Wh, up to 9 hrs', weight: '2.1 kg',
    os: 'Windows 11 Pro', ports: ['3x Thunderbolt 4', '2x USB-A 3.2', 'SD Express', 'HDMI 2.1', 'RJ45'],
    highlights: ['ISV-certified drivers', 'Color-calibrated factory panel', 'Tool-less RAM/SSD access', 'Quad-speaker array'],
    description: 'Engineered for render farms and CAD pipelines alike, the Vantage Pro 16 pairs workstation-grade graphics with a factory-calibrated display trusted by studios across India.',
    warranty: '3 Year Onsite Warranty', deliveryDays: 5, badges: ['Premium'], reviews: sampleReviews('vantage16'),
  },
  {
    id: 'p3', slug: 'strike-x15', brand: 'Strike', name: 'Strike X15',
    category: 'gaming', price: 124990, mrp: 144990, rating: 4.4, reviewCount: 501, stock: 24,
    images: img('strikex15', 4), processor: 'AMD Ryzen 9 8945HX', ram: '32GB DDR5', storage: '1TB NVMe SSD',
    graphics: 'NVIDIA RTX 4070 8GB', display: '15.6" QHD 240Hz', battery: '90Wh, up to 6 hrs', weight: '2.3 kg',
    os: 'Windows 11 Home', ports: ['1x Thunderbolt 4', '3x USB-A 3.2', 'HDMI 2.1', 'RJ45', '3.5mm audio'],
    highlights: ['240Hz QHD panel', 'Vapor-chamber cooling', 'Per-key RGB keyboard', 'Wi-Fi 7 ready'],
    description: 'The Strike X15 is tuned for competitive frame rates without sacrificing portability, backed by a vapor-chamber cooling system that keeps clocks high during marathon sessions.',
    warranty: '2 Year Kinetic Care', deliveryDays: 4, badges: ["Today's Deal"], reviews: sampleReviews('strikex15'),
  },
  {
    id: 'p4', slug: 'formwork-air-13', brand: 'Formwork', name: 'Formwork Air 13',
    category: 'ultrabook', price: 61990, mrp: 71990, rating: 4.3, reviewCount: 220, stock: 30,
    images: img('formworkair13', 4), processor: 'Intel Core i5-1340P', ram: '16GB LPDDR5', storage: '512GB NVMe SSD',
    graphics: 'Intel Iris Xe', display: '13.3" FHD+ IPS', battery: '56Wh, up to 14 hrs', weight: '1.1 kg',
    os: 'Windows 11 Home', ports: ['2x USB-C 3.2', '1x USB-A 3.2', 'microSD', '3.5mm audio'],
    highlights: ['Fanless silent design', 'All-day battery', 'Compact 1.1kg body', 'Backlit keyboard'],
    description: 'A quiet, fanless companion for writers, analysts and students who need long battery life more than raw horsepower.',
    warranty: '1 Year Standard', deliveryDays: 2, reviews: sampleReviews('formworkair13'),
  },
  {
    id: 'p5', slug: 'meridian-14-business', brand: 'Meridian', name: 'Meridian 14 Business',
    category: 'business', price: 84990, mrp: 96990, rating: 4.6, reviewCount: 178, stock: 15,
    images: img('meridian14', 4), processor: 'Intel Core Ultra 5 135U', ram: '16GB DDR5', storage: '1TB NVMe SSD',
    graphics: 'Intel Graphics', display: '14" WUXGA IPS, anti-glare', battery: '57Wh, up to 15 hrs', weight: '1.3 kg',
    os: 'Windows 11 Pro', ports: ['2x Thunderbolt 4', '2x USB-A 3.2', 'HDMI 2.0', 'RJ45', 'SIM slot'],
    highlights: ['Fingerprint + IR camera', 'TPM 2.0 security chip', 'Spill-resistant keyboard', '4G LTE optional'],
    description: 'Built for the boardroom and the branch office, the Meridian 14 pairs enterprise-grade security with a travel-ready chassis.',
    warranty: '3 Year Onsite Warranty', deliveryDays: 3, badges: ['Premium'], reviews: sampleReviews('meridian14'),
  },
  {
    id: 'p6', slug: 'flex-2in1-13', brand: 'Aeris', name: 'Aeris Flex 2-in-1 13',
    category: '2in1', price: 68990, mrp: 79990, rating: 4.2, reviewCount: 96, stock: 20,
    images: img('flex13', 4), processor: 'Intel Core i5-1335U', ram: '16GB LPDDR5', storage: '512GB NVMe SSD',
    graphics: 'Intel Iris Xe', display: '13" 2.8K OLED touch, 360° hinge', battery: '63Wh, up to 13 hrs', weight: '1.35 kg',
    os: 'Windows 11 Home', ports: ['2x USB-C 3.2', '1x USB-A 3.2', 'microSD'],
    highlights: ['360° convertible hinge', 'Pressure-sensitive stylus included', 'OLED touch display', 'Tablet mode auto-rotate'],
    description: 'Flip it, fold it, sketch on it. The Aeris Flex brings a vivid OLED touch display to a convertible form factor for creatives on the move.',
    warranty: '2 Year Kinetic Care', deliveryDays: 3, reviews: sampleReviews('flex13'),
  },
  {
    id: 'p7', slug: 'campus-book-15', brand: 'Formwork', name: 'Campus Book 15',
    category: 'student', price: 42990, mrp: 49990, rating: 4.1, reviewCount: 410, stock: 45,
    images: img('campusbook15', 4), processor: 'Intel Core i3-1315U', ram: '8GB DDR4', storage: '512GB NVMe SSD',
    graphics: 'Intel UHD Graphics', display: '15.6" FHD IPS', battery: '42Wh, up to 10 hrs', weight: '1.6 kg',
    os: 'Windows 11 Home', ports: ['1x USB-C 3.2', '2x USB-A 3.2', 'HDMI 1.4', '3.5mm audio'],
    highlights: ['Budget-friendly reliability', 'Spill-resistant keyboard', 'Free 1-year Office bundle', 'Lightweight for campus commutes'],
    description: 'Everything a student needs for lectures, assignments and video calls, priced to fit a semester budget.',
    warranty: '1 Year Standard', deliveryDays: 4, badges: ["Today's Deal"], reviews: sampleReviews('campusbook15'),
  },
  {
    id: 'p8', slug: 'strike-g17-titan', brand: 'Strike', name: 'Strike G17 Titan',
    category: 'gaming', price: 219990, mrp: 249990, rating: 4.8, reviewCount: 87, stock: 5,
    images: img('strikeg17', 4), processor: 'Intel Core i9-14900HX', ram: '32GB DDR5', storage: '2TB NVMe SSD',
    graphics: 'NVIDIA RTX 4090 16GB', display: '17.3" QHD 240Hz, G-Sync', battery: '99Wh, up to 5 hrs', weight: '3.1 kg',
    os: 'Windows 11 Home', ports: ['1x Thunderbolt 4', '3x USB-A 3.2', 'HDMI 2.1', 'RJ45'],
    highlights: ['Flagship RTX 4090 graphics', 'Quad-fan cooling system', 'Mechanical per-key RGB', 'Tool-less upgrade bay'],
    description: 'The Strike G17 Titan is the halo model of the lineup: desktop-class graphics in a chassis built to handle it without throttling.',
    warranty: '2 Year Kinetic Care', deliveryDays: 6, badges: ['New', 'Premium'], reviews: sampleReviews('strikeg17'),
  },
  {
    id: 'p9', slug: 'vantage-mobile-cad-15', brand: 'Vantage', name: 'Vantage Mobile CAD 15',
    category: 'workstation', price: 156990, mrp: 178990, rating: 4.5, reviewCount: 63, stock: 9,
    images: img('vantagecad15', 4), processor: 'Intel Core i7-14700H', ram: '32GB DDR5', storage: '1TB NVMe SSD',
    graphics: 'NVIDIA RTX 2000 Ada 8GB', display: '15.6" QHD+ IPS, 100% sRGB', battery: '76Wh, up to 10 hrs', weight: '1.9 kg',
    os: 'Windows 11 Pro', ports: ['2x Thunderbolt 4', '2x USB-A 3.2', 'SD Express', 'HDMI 2.1'],
    highlights: ['ISV certified for SolidWorks & AutoCAD', 'MIL-STD durability', 'Anti-glare precision display', 'Dual SSD bays'],
    description: 'A mid-weight workstation for engineers who need certified graphics drivers without carrying a desktop-replacement brick.',
    warranty: '3 Year Onsite Warranty', deliveryDays: 5, reviews: sampleReviews('vantagecad15'),
  },
  {
    id: 'p10', slug: 'meridian-x-fold', brand: 'Meridian', name: 'Meridian X Fold',
    category: '2in1', price: 149990, mrp: 169990, rating: 4.0, reviewCount: 41, stock: 6,
    images: img('meridianfold', 4), processor: 'Intel Core Ultra 7 155U', ram: '32GB LPDDR5', storage: '1TB NVMe SSD',
    graphics: 'Intel Arc Integrated', display: '13.5" foldable OLED, 2160x1350', battery: '65Wh, up to 12 hrs', weight: '1.15 kg',
    os: 'Windows 11 Pro', ports: ['2x Thunderbolt 4', '1x USB-A 3.2'],
    highlights: ['Foldable OLED canvas', 'Detachable Bluetooth keyboard', 'Kickstand-free foldable base', 'Pen included'],
    description: 'A conversation-starter for hybrid workers: fold it flat as a tablet, or prop it up as a dual-screen laptop in seconds.',
    warranty: '2 Year Kinetic Care', deliveryDays: 7, badges: ['New'], reviews: sampleReviews('meridianfold'),
  },
  {
    id: 'p11', slug: 'formwork-book-e14', brand: 'Formwork', name: 'Formwork Book E14',
    category: 'business', price: 54990, mrp: 62990, rating: 4.2, reviewCount: 133, stock: 27,
    images: img('formworkE14', 4), processor: 'AMD Ryzen 5 7530U', ram: '16GB DDR5', storage: '512GB NVMe SSD',
    graphics: 'AMD Radeon Graphics', display: '14" FHD IPS', battery: '50Wh, up to 12 hrs', weight: '1.4 kg',
    os: 'Windows 11 Pro', ports: ['1x USB-C 3.2', '2x USB-A 3.2', 'HDMI 1.4', 'RJ45'],
    highlights: ['Value enterprise pick', 'Fingerprint reader', 'Spill-resistant keyboard', 'Kensington lock slot'],
    description: 'A no-fuss workhorse for fleet deployments where reliability and manageability matter more than flash.',
    warranty: '1 Year Standard', deliveryDays: 3, reviews: sampleReviews('formworkE14'),
  },
  {
    id: 'p12', slug: 'campus-book-air-14', brand: 'Aeris', name: 'Campus Air 14',
    category: 'student', price: 49990, mrp: 57990, rating: 4.3, reviewCount: 267, stock: 33,
    images: img('campusair14', 4), processor: 'Intel Core i5-1335U', ram: '16GB LPDDR5', storage: '512GB NVMe SSD',
    graphics: 'Intel Iris Xe', display: '14" FHD+ IPS', battery: '55Wh, up to 13 hrs', weight: '1.25 kg',
    os: 'Windows 11 Home', ports: ['1x USB-C 3.2', '2x USB-A 3.2', 'HDMI 1.4', '3.5mm audio'],
    highlights: ['Lightweight metal chassis', 'Backlit keyboard', 'Fast charge to 50% in 30 min', '1-year Office included'],
    description: 'The step-up campus laptop for students who want a metal chassis and faster charging without a workstation price tag.',
    warranty: '2 Year Kinetic Care', deliveryDays: 3, badges: ['Bestseller'], reviews: sampleReviews('campusair14'),
  },
];

export const brands = ['Aeris', 'Vantage', 'Strike', 'Formwork', 'Meridian'];

export const categories: { id: Product['category']; label: string; description: string }[] = [
  { id: 'ultrabook', label: 'Ultrabooks', description: 'Slim, light, all-day battery' },
  { id: 'gaming', label: 'Gaming', description: 'High refresh, discrete graphics' },
  { id: 'workstation', label: 'Workstations', description: 'ISV-certified, pro-grade' },
  { id: 'business', label: 'Business', description: 'Security-first, travel-ready' },
  { id: 'student', label: 'Student', description: 'Reliable and budget-friendly' },
  { id: '2in1', label: '2-in-1', description: 'Convertible touch displays' },
];

export const processorFilters = ['Intel Core i3', 'Intel Core i5', 'Intel Core i7', 'Intel Core i9', 'Intel Core Ultra', 'AMD Ryzen 5', 'AMD Ryzen 9'];
export const ramFilters = ['8GB', '16GB', '32GB', '64GB'];
export const storageFilters = ['512GB', '1TB', '2TB'];
export const graphicsFilters = ['Integrated', 'RTX 2000 Ada', 'RTX 4000 Ada', 'RTX 4070', 'RTX 4090'];
