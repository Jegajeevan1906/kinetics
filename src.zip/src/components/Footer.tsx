import { Link } from 'react-router-dom';
import { useState } from 'react';
import { CreditCard, ArrowRight } from 'lucide-react';
import { useStore } from '../lib/store';

export function Footer() {
  const { pushToast } = useStore();
  const [email, setEmail] = useState('');

  const subscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    pushToast('Subscribed to Kinetic newsletter', 'success');
    setEmail('');
  };

  return (
    <footer className="border-t border-hairline bg-canvas-secondary">
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-10 px-6 py-14 sm:grid-cols-3 md:grid-cols-5 lg:px-8">
        <div className="col-span-2 sm:col-span-1">
          <div className="font-display text-xl font-black tracking-tight">KINETIC<span className="text-primary">.</span></div>
          <p className="mt-3 text-sm leading-relaxed text-ink-muted">India's premium destination for high-performance laptops and workstations. Curated, warranted, GST compliant.</p>
          <div className="mt-4 flex items-center gap-2 text-ink-muted">
            <CreditCard size={16} /><span className="text-xs">Visa · MasterCard · UPI · RuPay · EMI</span>
          </div>
        </div>
        <FooterCol title="Shop" links={[
          ['Laptops', '/products'], ['Deals', '/deals'], ['New Arrivals', '/new-arrivals'], ['Brands', '/brands'], ['Gaming', '/category/gaming'], ['Workstations', '/category/workstation'],
        ]} />
        <FooterCol title="Support" links={[
          ['Contact', '/contact'], ['FAQ', '/faq'], ['Track Order', '/dashboard'], ['Return Policy', '/return-policy'], ['Shipping', '/shipping-policy'],
        ]} />
        <FooterCol title="Company" links={[
          ['About Kinetic', '/about'], ['Admin Demo', '/admin'], ['Careers', '/about'], ['Privacy', '/privacy'], ['Terms', '/terms'],
        ]} />
        <div>
          <h4 className="font-display text-sm font-bold text-ink">Newsletter</h4>
          <p className="mt-3 text-sm text-ink-muted">Get early access to launches and exclusive EMI offers.</p>
          <form onSubmit={subscribe} className="mt-3 flex items-center overflow-hidden rounded-full border border-hairline bg-card pl-4 shadow-sm focus-within:border-primary">
            <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" placeholder="you@email.com" className="w-full bg-transparent py-2.5 text-xs text-ink outline-none placeholder:text-ink-muted" />
            <button aria-label="Subscribe" className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary text-white transition-colors hover:bg-primary-hover">
              <ArrowRight size={15} />
            </button>
          </form>
        </div>
      </div>
      <div className="border-t border-hairline px-6 py-5 text-center text-xs text-ink-muted lg:px-8">
        © 2026 Kinetic Retail India Pvt Ltd. All rights reserved. CIN: U52100KA2024PTC000000
        <div className="mt-2 flex flex-wrap justify-center gap-x-5 gap-y-1.5">
          <Link to="/privacy" className="hover:text-primary">Privacy</Link>
          <Link to="/terms" className="hover:text-primary">Terms</Link>
          <Link to="/return-policy" className="hover:text-primary">Returns</Link>
          <Link to="/shipping-policy" className="hover:text-primary">Shipping</Link>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({ title, links }: { title: string; links: [string, string][] }) {
  return (
    <div>
      <h4 className="font-display text-sm font-bold text-ink">{title}</h4>
      <ul className="mt-3 space-y-2.5 text-sm text-ink-muted">
        {links.map(([label, href]) => (
          <li key={label}><Link to={href} className="transition-colors hover:text-primary">{label}</Link></li>
        ))}
      </ul>
    </div>
  );
}
