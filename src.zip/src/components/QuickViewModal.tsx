import { X } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { Product } from '../data/types';
import { formatINR, discountPercent } from '../lib/format';
import { RatingBadge } from './StarRating';
import { useStore } from '../lib/store';

export function QuickViewModal({ product, onClose }: { product: Product; onClose: () => void }) {
  const { addToCart } = useStore();
  const off = discountPercent(product.price, product.mrp);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/50 p-4 backdrop-blur-sm animate-fade-in" onClick={onClose}>
      <div
        className="animate-scale-in relative grid w-full max-w-2xl grid-cols-1 gap-6 overflow-hidden rounded-[24px] border border-hairline bg-card p-5 shadow-card-hover sm:grid-cols-2 sm:p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onClose} aria-label="Close" className="absolute right-3 top-3 z-10 flex h-9 w-9 items-center justify-center rounded-full bg-canvas-secondary text-ink-muted transition-colors hover:bg-ink hover:text-white">
          <X size={16} />
        </button>
        <img src={product.images[0]} alt={product.name} className="aspect-square w-full rounded-2xl bg-canvas-secondary object-cover" />
        <div className="flex flex-col gap-2">
          <span className="text-xs font-semibold uppercase tracking-wide text-ink-muted">{product.brand}</span>
          <h3 className="font-display text-lg font-bold text-ink">{product.name}</h3>
          <RatingBadge rating={product.rating} reviewCount={product.reviewCount} />
          <div className="flex items-baseline gap-2">
            <span className="font-display text-xl font-extrabold text-ink">{formatINR(product.price)}</span>
            {off > 0 && <span className="text-sm text-ink-muted line-through">{formatINR(product.mrp)}</span>}
          </div>
          <ul className="mt-1 space-y-1 text-xs text-ink-muted">
            <li>CPU: {product.processor}</li>
            <li>RAM: {product.ram}</li>
            <li>Storage: {product.storage}</li>
            <li>Display: {product.display}</li>
          </ul>
          <div className="mt-auto flex gap-2.5 pt-3">
            <button
              onClick={() => { addToCart(product.id); onClose(); }}
              className="flex-1 rounded-full bg-primary py-2.5 text-sm font-semibold text-white transition-colors hover:bg-primary-hover"
            >
              Add to Cart
            </button>
            <Link to={`/product/${product.slug}`} onClick={onClose} className="flex-1 rounded-full border border-hairline py-2.5 text-center text-sm font-semibold text-ink transition-colors hover:border-primary hover:text-primary">
              View Details
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
