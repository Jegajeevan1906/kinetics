import { brands, processorFilters, ramFilters, storageFilters, graphicsFilters } from '../data/products';

export interface Filters {
  brands: string[];
  minPrice: number;
  maxPrice: number;
  processor: string[];
  ram: string[];
  storage: string[];
  graphics: string[];
  minRating: number;
  inStockOnly: boolean;
}

export const defaultFilters: Filters = {
  brands: [], minPrice: 0, maxPrice: 250000, processor: [], ram: [], storage: [], graphics: [], minRating: 0, inStockOnly: false,
};

function toggle<T>(arr: T[], v: T): T[] {
  return arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v];
}

export function FilterSidebar({ filters, setFilters }: { filters: Filters; setFilters: (f: Filters) => void }) {
  return (
    <aside className="w-full shrink-0 space-y-7 rounded-[20px] border border-hairline bg-card p-5 sm:w-60">
      <div>
        <div className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-muted">Price up to</div>
        <input
          type="range" min={20000} max={250000} step={5000}
          value={filters.maxPrice}
          onChange={(e) => setFilters({ ...filters, maxPrice: Number(e.target.value) })}
          className="w-full accent-primary"
        />
        <div className="mt-1 text-xs font-semibold text-primary">₹{filters.maxPrice.toLocaleString('en-IN')}</div>
      </div>

      <FilterGroup title="Brand" options={brands} selected={filters.brands} onChange={(v) => setFilters({ ...filters, brands: toggle(filters.brands, v) })} />
      <FilterGroup title="Processor" options={processorFilters} selected={filters.processor} onChange={(v) => setFilters({ ...filters, processor: toggle(filters.processor, v) })} />
      <FilterGroup title="RAM" options={ramFilters} selected={filters.ram} onChange={(v) => setFilters({ ...filters, ram: toggle(filters.ram, v) })} />
      <FilterGroup title="Storage" options={storageFilters} selected={filters.storage} onChange={(v) => setFilters({ ...filters, storage: toggle(filters.storage, v) })} />
      <FilterGroup title="Graphics" options={graphicsFilters} selected={filters.graphics} onChange={(v) => setFilters({ ...filters, graphics: toggle(filters.graphics, v) })} />

      <div>
        <div className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-muted">Rating</div>
        <div className="flex flex-wrap gap-2">
          {[4, 3, 2].map((r) => (
            <button
              key={r}
              onClick={() => setFilters({ ...filters, minRating: filters.minRating === r ? 0 : r })}
              className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${filters.minRating === r ? 'border-primary bg-primary/10 text-primary' : 'border-hairline text-ink-muted hover:border-primary/40'}`}
            >
              {r}★ &amp; up
            </button>
          ))}
        </div>
      </div>

      <label className="flex items-center gap-2 text-sm font-medium text-ink">
        <input type="checkbox" checked={filters.inStockOnly} onChange={(e) => setFilters({ ...filters, inStockOnly: e.target.checked })} className="h-4 w-4 accent-primary" />
        In stock only
      </label>

      <button onClick={() => setFilters(defaultFilters)} className="text-xs font-semibold text-primary hover:underline">
        Clear all filters
      </button>
    </aside>
  );
}

function FilterGroup({ title, options, selected, onChange }: { title: string; options: string[]; selected: string[]; onChange: (v: string) => void }) {
  return (
    <div>
      <div className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-muted">{title}</div>
      <div className="space-y-2">
        {options.map((o) => (
          <label key={o} className="flex items-center gap-2 text-sm text-ink-muted transition-colors hover:text-ink">
            <input type="checkbox" checked={selected.includes(o)} onChange={() => onChange(o)} className="h-4 w-4 accent-primary" />
            {o}
          </label>
        ))}
      </div>
    </div>
  );
}
