import { Link } from 'react-router-dom';
import { Heart, Eye, Truck } from 'lucide-react';
import type { Product } from '../data/types';
import { formatINR, discountPercent, deliveryDateFrom } from '../lib/format';
import { RatingBadge } from './StarRating';
import { useStore } from '../lib/store';
import { useState } from 'react';
import { QuickViewModal } from './QuickViewModal';

export function ProductCard({ product }: { product: Product }) {
  const { wishlist, toggleWishlist, addToCart } = useStore();
  const [quickView, setQuickView] = useState(false);
  const inWishlist = wishlist.includes(product.id);
  const off = discountPercent(product.price, product.mrp);

  return (
    <>
      <div className="group relative flex flex-col overflow-hidden rounded-[20px] border border-hairline bg-card shadow-card transition-all duration-300 hover:-translate-y-1.5 hover:border-primary/30 hover:shadow-card-hover">
        <div className="relative aspect-[4/3] overflow-hidden bg-canvas-secondary">
          <Link to={`/product/${product.slug}`}>
            <img
              src={product.images[0]}
              alt={product.name}
              className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-110"
              loading="lazy"
            />
          </Link>
          {product.badges?.[0] && (
            <span className="absolute left-2.5 top-2.5 rounded-full bg-accent px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-white shadow-sm">
              {product.badges[0]}
            </span>
          )}
          {off > 0 && (
            <span className="absolute right-2.5 top-2.5 rounded-full bg-discount px-2.5 py-1 text-[10px] font-bold text-white shadow-sm">
              {off}% OFF
            </span>
          )}
          <div className="absolute inset-x-0 bottom-0 flex translate-y-full justify-center gap-2 p-2.5 transition-transform duration-300 group-hover:translate-y-0">
            <button
              onClick={() => toggleWishlist(product.id)}
              aria-label="Toggle wishlist"
              className={`flex h-9 w-9 items-center justify-center rounded-full shadow-md backdrop-blur transition-colors ${inWishlist ? 'bg-primary text-white' : 'bg-white/90 text-ink hover:bg-primary hover:text-white'}`}
            >
              <Heart size={15} className={inWishlist ? 'fill-current' : ''} />
            </button>
            <button
              onClick={() => setQuickView(true)}
              aria-label="Quick view"
              className="flex h-9 w-9 items-center justify-center rounded-full bg-white/90 text-ink shadow-md backdrop-blur transition-colors hover:bg-primary hover:text-white"
            >
              <Eye size={15} />
            </button>
          </div>
        </div>

        <div className="flex flex-1 flex-col gap-1.5 p-4">
          <span className="text-[11px] font-semibold uppercase tracking-wide text-ink-muted">{product.brand}</span>
          <Link to={`/product/${product.slug}`} className="font-display text-sm font-semibold leading-snug text-ink transition-colors hover:text-primary">
            {product.name}
          </Link>
          <div className="flex items-center gap-2 text-[11px] text-ink-muted">
            <span>{product.processor.split(' ').slice(0, 3).join(' ')}</span>
            <span className="text-hairline">/</span>
            <span>{product.ram}</span>
          </div>
          <RatingBadge rating={product.rating} reviewCount={product.reviewCount} />
          <div className="mt-1 flex items-baseline gap-2">
            <span className="font-display text-lg font-extrabold text-ink">{formatINR(product.price)}</span>
            {off > 0 && <span className="text-xs text-ink-muted line-through">{formatINR(product.mrp)}</span>}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-ink-muted">
            <Truck size={12} />
            <span>Delivery by {deliveryDateFrom(product.deliveryDays)}</span>
          </div>
          <button
            onClick={() => addToCart(product.id)}
            disabled={product.stock === 0}
            className="mt-2.5 w-full rounded-full bg-ink py-2.5 text-xs font-semibold text-white transition-colors hover:bg-primary disabled:cursor-not-allowed disabled:bg-canvas-secondary disabled:text-ink-muted"
          >
            {product.stock === 0 ? 'Out of Stock' : 'Add to Cart'}
          </button>
        </div>
      </div>
      {quickView && <QuickViewModal product={product} onClose={() => setQuickView(false)} />}
    </>
  );
}
